import fs from 'node:fs';
const d=JSON.parse(fs.readFileSync('data/store.json','utf8'));
const publicData={products:d.products,categories:d.categories,brands:d.brands,heroSlides:d.heroSlides,attendants:d.attendants,storeSettings:d.storeSettings};
fs.writeFileSync('public/store-data.json',JSON.stringify(publicData,null,2));
