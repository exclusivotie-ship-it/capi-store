# CAPI STORE — Cloudflare Pages (código-fonte)

Este ZIP contém o código-fonte. O uploader de arrastar-e-soltar do Cloudflare Pages não compila projetos React/Vite: ele espera ficheiros estáticos já compilados. Para este pacote, conecte a pasta a um repositório Git e crie um projeto Pages com:

- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Node.js: 22 ou superior

O build gera `dist` automaticamente. Se quiser usar o uploader manual, primeiro instale as dependências e compile localmente (`npm install` e `npm run build`) e depois envie **o conteúdo de `dist`**, nunca o ZIP do código-fonte.

A mensagem sobre Wrangler ocorreu porque o ZIP anterior continha `wrangler.json`, que não é necessário para um site Pages estático. Esse ficheiro foi removido desta versão.

Funcionalidades incluídas: catálogo, pesquisa, filtros, detalhes, carrinho, favoritos locais e encomendas preparadas para WhatsApp. Login, administração e registo de encomendas precisam de backend.
