import React, { useState, useEffect, useMemo } from 'react';
import { StoreProvider, useStore } from './context/StoreContext.js';
import { Header } from './components/Header.js';
import { DynamicHero } from './components/DynamicHero.js';
import { ProductCard } from './components/ProductCard.js';
import { ProductDetailModal } from './components/ProductDetailModal.js';
import { CartDrawer } from './components/CartDrawer.js';
import { CheckoutModal } from './components/CheckoutModal.js';
import { AttendantsModal } from './components/AttendantsModal.js';
import { FavoritesDrawer } from './components/FavoritesDrawer.js';
import { Product, HeroSlide, Category } from './types/index.js';
import {
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  CreditCard,
  MessageCircle,
  Sparkles,
  ArrowRight,
  ChevronRight,
  Filter,
  CheckCircle2,
  HelpCircle,
  PhoneCall,
  Mail,
  MapPin,
} from 'lucide-react';
import { formatKz, buildGeneralHelpWhatsAppUrl } from './utils/format.js';
import storeData from '../public/store-data.json';

function StoreFront() {
  const {
    selectedProduct,
    setSelectedProduct,
    setIsAttendantsOpen,
    storeSettings,
    activeAttendantForCategory,
  } = useStore();

  const [products, setProducts] = useState<Product[]>([]);
  const [slides, setSlides] = useState<HeroSlide[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [selectedBrand, setSelectedBrand] = useState<string>('todas');
  const [sortBy, setSortBy] = useState<string>('popular');
  const [onlyInStock, setOnlyInStock] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch initial store data
  useEffect(() => {
    const data = storeData as { products: Product[]; heroSlides: HeroSlide[]; categories: Category[] };
    setProducts(data.products.filter((product) => product.isPublished));
    setSlides(data.heroSlides);
    setCategories(data.categories);
    setIsLoading(false);
  }, []);

  // Filtered & Sorted products for the main catalog grid
  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (selectedCategory !== 'todos') {
      result = result.filter(
        (p) =>
          p.categoryId === selectedCategory ||
          p.subcategoryId.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    if (selectedBrand !== 'todas') {
      result = result.filter((p) => p.brand.toLowerCase() === selectedBrand.toLowerCase());
    }

    if (onlyInStock) {
      result = result.filter((p) => p.stock > 0);
    }

    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'newest') {
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } else {
      // Popular
      result.sort((a, b) => b.reviewCount - a.reviewCount);
    }

    return result;
  }, [products, selectedCategory, selectedBrand, onlyInStock, sortBy]);

  // Featured lists for special homepage showcases
  const smartphonesShowcase = useMemo(() => {
    return products.filter((p) => p.categoryId === 'cat-smartphones').slice(0, 4);
  }, [products]);

  const gamingShowcase = useMemo(() => {
    return products.filter((p) => p.categoryId === 'cat-gaming' || p.categoryId === 'cat-televisores').slice(0, 4);
  }, [products]);

  const audioShowcase = useMemo(() => {
    return products.filter((p) => p.categoryId === 'cat-audio' || p.categoryId === 'cat-acessorios').slice(0, 4);
  }, [products]);

  const computersShowcase = useMemo(() => {
    return products.filter((p) => p.categoryId === 'cat-computadores').slice(0, 4);
  }, [products]);

  const primaryAttendant = activeAttendantForCategory();

  // Scroll to catalog section
  const handleScrollToCatalog = () => {
    const el = document.getElementById('catalogo-completo');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleScrollToDeals = () => {
    setSelectedCategory('todos');
    setSortBy('popular');
    const el = document.getElementById('catalogo-completo');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0B0C0E] text-white flex flex-col font-sans selection:bg-[#E5C158] selection:text-[#0B0C0E] relative">
      {/* Background Subtle Golden Ambient Lighting Glows */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(229,193,88,0.06),rgba(11,12,14,0))] pointer-events-none z-0" />
      <div className="fixed bottom-0 right-0 w-[500px] h-[500px] bg-[#E5C158]/5 rounded-full blur-[120px] pointer-events-none z-0" />

      {/* 1. Global Header Navigation */}
      <Header
        onNavigateCategory={(slug) => {
          setSelectedCategory(slug);
          handleScrollToCatalog();
        }}
        selectedCategorySlug={selectedCategory}
      />

      {/* 2. Cinematic 6-Second Dynamic Hero Slider */}
      <DynamicHero
        slides={slides}
        onExploreProducts={handleScrollToCatalog}
        onViewDeals={handleScrollToDeals}
      />

      {/* 3. Popular Categories Bar */}
      <section className="py-10 border-b border-[#22242C] bg-[#0E1015] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">Categorias em Destaque</h2>
              <p className="text-xs text-slate-400">Equipamentos electrónicos seleccionados com garantia oficial</p>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('todos');
                handleScrollToCatalog();
              }}
              className="text-xs text-[#FBE285] hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              Ver Todas <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            {categories.slice(0, 6).map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  handleScrollToCatalog();
                }}
                className="group p-4 bg-[#131418] hover:bg-[#181920] border border-[#22242C] hover:border-[#E5C158]/50 rounded-2xl text-left transition-all duration-300 flex flex-col justify-between overflow-hidden relative cursor-pointer hover:shadow-lg hover:shadow-[#E5C158]/10"
              >
                <div className="w-12 h-12 rounded-xl bg-black/60 border border-[#22242C] overflow-hidden mb-3">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-white group-hover:text-[#FBE285] transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Explorar linha</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Showcase: Smartphones Flagship (From User Image cd721a99) */}
      <section className="py-12 border-b border-[#22242C] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#E5C158] uppercase tracking-wider mb-1">
                <Sparkles className="w-3.5 h-3.5" /> Smartphones Topo de Gama
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Os Melhores Smartphones do Mercado
              </h2>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('cat-smartphones');
                handleScrollToCatalog();
              }}
              className="text-xs text-[#FBE285] hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              Ver todos os 20 modelos <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {smartphonesShowcase.map((prod) => (
              <ProductCard
                key={prod.id}
                product={prod}
                onOpenDetail={(p) => setSelectedProduct(p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 5. Showcase: Consolas, TVs & Gaming Next-Gen (From User Image e513e223) */}
      <section className="py-12 border-b border-[#22242C] bg-[#0E1015] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#E5C158] uppercase tracking-wider mb-1">
                <Sparkles className="w-3.5 h-3.5" /> Entretenimento & Competitividade
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Gaming, Smart TVs & Transmissão
              </h2>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('cat-gaming');
                handleScrollToCatalog();
              }}
              className="text-xs text-[#FBE285] hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              Ver todos os 20 artigos <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {gamingShowcase.map((prod) => (
              <ProductCard
                key={prod.id}
                product={prod}
                onOpenDetail={(p) => setSelectedProduct(p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 6. Showcase: Áudio de Alta Fidelidade & Acessórios (From User Image 514ba86c) */}
      <section className="py-12 border-b border-[#22242C] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#E5C158] uppercase tracking-wider mb-1">
                <Sparkles className="w-3.5 h-3.5" /> Fidelidade Sonora & Acessórios
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Áudio Premium, Wearables & Energia
              </h2>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('cat-audio');
                handleScrollToCatalog();
              }}
              className="text-xs text-[#FBE285] hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              Ver todos os 20 artigos <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {audioShowcase.map((prod) => (
              <ProductCard
                key={prod.id}
                product={prod}
                onOpenDetail={(p) => setSelectedProduct(p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 7. Showcase: Computadores, Workstations & Armazenamento (From User Image c8615b1a) */}
      <section className="py-12 border-b border-[#22242C] bg-[#0E1015] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#E5C158] uppercase tracking-wider mb-1">
                <Sparkles className="w-3.5 h-3.5" /> Produtividade & Computação
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Portáteis, Monitores & Discos de Armazenamento
              </h2>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('cat-computadores');
                handleScrollToCatalog();
              }}
              className="text-xs text-[#FBE285] hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              Ver todos os 20 artigos <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {computersShowcase.map((prod) => (
              <ProductCard
                key={prod.id}
                product={prod}
                onOpenDetail={(p) => setSelectedProduct(p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 8. Full Dynamic Catalog Section (Filterable & Searchable) */}
      <section id="catalogo-completo" className="py-14 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 flex-1 relative z-10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 border-b border-[#22242C] pb-6">
          <div>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Catálogo Completo CAPI STORE
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              {filteredProducts.length} artigo(s) disponível(eis) para encomenda imediata em Angola
            </p>
          </div>

          {/* Controls: Sort & In-Stock toggle */}
          <div className="flex flex-wrap items-center gap-3 text-xs w-full sm:w-auto">
            <label className="flex items-center gap-2 text-slate-300 bg-[#131418] px-3 py-2 rounded-xl border border-[#22242C] cursor-pointer">
              <input
                type="checkbox"
                checked={onlyInStock}
                onChange={(e) => setOnlyInStock(e.target.checked)}
                className="rounded accent-[#E5C158]"
              />
              <span>Apenas com Stock</span>
            </label>

            <div className="flex items-center gap-1.5 bg-[#131418] px-3 py-2 rounded-xl border border-[#22242C]">
              <span className="text-slate-400">Ordenar por:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-transparent text-[#FBE285] font-bold focus:outline-none cursor-pointer"
              >
                <option value="popular" className="bg-[#131418] text-white">Mais Populares</option>
                <option value="price-asc" className="bg-[#131418] text-white">Menor Preço (Kz)</option>
                <option value="price-desc" className="bg-[#131418] text-white">Maior Preço (Kz)</option>
                <option value="rating" className="bg-[#131418] text-white">Melhor Avaliados</option>
                <option value="newest" className="bg-[#131418] text-white">Mais Recentes</option>
              </select>
            </div>
          </div>
        </div>

        {/* Categories Pill Filters */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2 text-xs">
          <button
            onClick={() => setSelectedCategory('todos')}
            className={`px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === 'todos'
                ? 'gold-btn-gradient text-[#0B0C0E] font-black shadow-md shadow-[#E5C158]/25'
                : 'bg-[#131418] text-slate-400 hover:text-white border border-[#22242C] hover:border-[#E5C158]/40'
            }`}
          >
            Todos os Artigos ({products.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'gold-btn-gradient text-[#0B0C0E] font-black shadow-md shadow-[#E5C158]/25'
                  : 'bg-[#131418] text-slate-400 hover:text-white border border-[#22242C] hover:border-[#E5C158]/40'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Product Cards Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 py-12">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-80 bg-[#131418] rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((prod) => (
              <ProductCard
                key={prod.id}
                product={prod}
                onOpenDetail={(p) => setSelectedProduct(p)}
              />
            ))}
          </div>
        ) : (
          <div className="p-16 bg-[#131418] rounded-3xl border border-[#22242C] text-center space-y-4">
            <p className="text-base font-bold text-white">Nenhum produto encontrado com os filtros actuais.</p>
            <p className="text-xs text-slate-400">Tente remover o filtro de marca ou categoria seleccionada.</p>
            <button
              onClick={() => {
                setSelectedCategory('todos');
                setSelectedBrand('todas');
                setOnlyInStock(false);
              }}
              className="px-5 py-2.5 gold-btn-gradient text-[#0B0C0E] text-xs font-black rounded-xl cursor-pointer"
            >
              Limpar Filtros
            </button>
          </div>
        )}
      </section>

      {/* 9. Value Pillars & Store Advantages */}
      <section className="py-14 border-t border-[#22242C] bg-[#0E1015] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black text-white">Porquê Escolher a CAPI STORE?</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Compromisso inegociável com a satisfação e segurança de compra em Angola
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 bg-[#131418] rounded-2xl border border-[#22242C] hover:border-[#E5C158]/40 transition-all space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#E5C158]/15 border border-[#E5C158]/30 text-[#FBE285] flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Garantia Oficial 12 a 24 Meses</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Todos os produtos são selados de fábrica e contam com assistência e substituição em caso de defeito de fabrico.
              </p>
            </div>

            <div className="p-6 bg-[#131418] rounded-2xl border border-[#22242C] hover:border-emerald-500/40 transition-all space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                <Truck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Entregas em Toda Angola</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Logística com estafetas próprios em Luanda (1 a 2 dias úteis) e envios expressos para as outras províncias.
              </p>
            </div>

            <div className="p-6 bg-[#131418] rounded-2xl border border-[#22242C] hover:border-[#E5C158]/40 transition-all space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#E5C158]/15 border border-[#E5C158]/30 text-[#FBE285] flex items-center justify-center">
                <CreditCard className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Multicaixa Express & Bancos</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Contacte a loja para combinar o pagamento.
              </p>
            </div>

            <div className="p-6 bg-[#131418] rounded-2xl border border-[#22242C] hover:border-emerald-500/40 transition-all space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                <MessageCircle className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Atendimento Humano WhatsApp</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Consultores técnicos disponíveis para orientar a sua escolha, enviar fotografias reais e tirar dúvidas técnicas.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 10. How To Buy (Passo a Passo Sem Login) */}
      <section className="py-14 border-t border-[#22242C] bg-[#0B0C0E] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black text-white">Como Comprar Sem Criar Conta</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Processo de compra directo em apenas 3 passos rápidos
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-6 bg-[#131418] rounded-2xl border border-[#22242C] space-y-3 text-center relative">
              <div className="w-10 h-10 rounded-full gold-btn-gradient text-[#0B0C0E] font-black text-sm flex items-center justify-center mx-auto mb-2 shadow-lg shadow-[#E5C158]/25">
                1
              </div>
              <h3 className="text-sm font-bold text-white">Escolha os Seus Favoritos</h3>
              <p className="text-xs text-slate-400">
                Navegue pelas categorias e adicione os equipamentos pretendidos ao carrinho ou compre directamente pelo WhatsApp.
              </p>
            </div>

            <div className="p-6 bg-[#131418] rounded-2xl border border-[#22242C] space-y-3 text-center relative">
              <div className="w-10 h-10 rounded-full gold-btn-gradient text-[#0B0C0E] font-black text-sm flex items-center justify-center mx-auto mb-2 shadow-lg shadow-[#E5C158]/25">
                2
              </div>
              <h3 className="text-sm font-bold text-white">Preencha os Dados de Entrega</h3>
              <p className="text-xs text-slate-400">
                Informe o seu nome, contacto telefónico e endereço em Angola. Sem necessidade de senhas ou palavras-passe.
              </p>
            </div>

            <div className="p-6 bg-[#131418] rounded-2xl border border-[#22242C] space-y-3 text-center relative">
              <div className="w-10 h-10 rounded-full gold-btn-gradient text-[#0B0C0E] font-black text-sm flex items-center justify-center mx-auto mb-2 shadow-lg shadow-[#E5C158]/25">
                3
              </div>
              <h3 className="text-sm font-bold text-white">Receba e Acompanhe</h3>
              <p className="text-xs text-slate-400">
                Receba o número de pedido e código de rastreio para acompanhar o progresso até à sua porta com garantia inclusa.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 11. FAQ: Perguntas Frequentes em Angola */}
      <section className="py-14 border-t border-[#22242C] bg-[#0E1015] relative z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-black text-white">Perguntas Frequentes (FAQ)</h2>
            <p className="text-xs text-slate-400">Respostas claras para as suas dúvidas mais comuns</p>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-4 bg-[#131418] rounded-2xl border border-[#22242C] space-y-1.5">
              <h4 className="font-bold text-[#FBE285] text-sm">É obrigatório criar uma conta para fazer uma encomenda?</h4>
              <p className="text-slate-300 leading-relaxed">
                Não. A nossa plataforma foi concebida para ser ágil e acessível. Basta adicionar os produtos pretendidos ao carrinho e preencher os dados de contacto e morada de entrega.
              </p>
            </div>

            <div className="p-4 bg-[#131418] rounded-2xl border border-[#22242C] space-y-1.5">
              <h4 className="font-bold text-[#FBE285] text-sm">Quais são os métodos de pagamento aceites?</h4>
              <p className="text-slate-300 leading-relaxed">
                Fale com a CAPI STORE para combinar o pagamento do pedido.
              </p>
            </div>

            <div className="p-4 bg-[#131418] rounded-2xl border border-[#22242C] space-y-1.5">
              <h4 className="font-bold text-[#FBE285] text-sm">Quanto tempo demora a entrega nas províncias fora de Luanda?</h4>
              <p className="text-slate-300 leading-relaxed">
                Para Luanda as entregas demoram de 24 a 48 horas úteis. Para as províncias de Benguela, Huambo, Huíla, Cabinda e outras, os envios são expedidos via serviços expresso com prazo de 2 a 5 dias úteis.
              </p>
            </div>

            <div className="p-4 bg-[#131418] rounded-2xl border border-[#22242C] space-y-1.5">
              <h4 className="font-bold text-[#FBE285] text-sm">Como posso acompanhar o estado da minha encomenda?</h4>
              <p className="text-slate-300 leading-relaxed">
                Fale com a equipa CAPI STORE pelo WhatsApp para confirmar o seu pedido.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 12. Global Footer */}
      <footer className="border-t border-[#22242C] bg-[#0B0C0E] py-12 text-xs text-slate-400 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Col 1: Brand Info */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="font-black text-xl text-white tracking-wider">CAPI</span>
                <span className="font-black text-xl gold-text-gradient tracking-widest">STORE</span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed">
                {storeSettings?.tagline || 'Tecnologia que transforma o seu dia.'} A sua loja de referência de electrónica premium em Angola.
              </p>
              <div className="pt-2 text-[#E5C158] font-mono text-[11px]">
                Venda de telemóveis e acessórios
              </div>
            </div>

            {/* Col 2: Fast Links */}
            <div className="space-y-2">
              <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Navegação Rápida</h4>
              <ul className="space-y-1.5">
                <li>
                  <button onClick={() => { setSelectedCategory('todos'); handleScrollToCatalog(); }} className="hover:text-[#FBE285] cursor-pointer transition-colors">
                    Catálogo de Artigos
                  </button>
                </li>
<li>
                  <button onClick={() => setIsAttendantsOpen(true)} className="hover:text-[#FBE285] cursor-pointer transition-colors">
                    Consultoria & Atendentes
                  </button>
                </li>
</ul>
            </div>

            {/* Col 3: Coordinates in Luanda */}
            <div className="space-y-2">
              <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Contactos & Morada</h4>
              <ul className="space-y-1.5">
                <li className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-[#E5C158] flex-shrink-0" />
                  <span>{storeSettings?.address || 'Angola'}</span>
                </li>
                <li className="flex items-center gap-2">
                  <PhoneCall className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  <span>{storeSettings?.phone || '+244 972 973 849 / +244 958 690 893'}</span>
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span>{storeSettings?.email || 'alicamara9@gmail.com'}</span>
                </li>
              </ul>
            </div>

            {/* Col 4: Payments Accepted */}
            <div className="space-y-2">
              <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Métodos de Pagamento</h4>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Contacte a CAPI STORE pelo WhatsApp para combinar a forma de pagamento.
              </p>
              <div className="pt-2 flex flex-wrap gap-2 text-[10px] font-mono">
                <span className="bg-[#131418] px-2 py-1 rounded border border-[#22242C] text-[#FBE285]">Multicaixa Express</span>
                <span className="bg-[#131418] px-2 py-1 rounded border border-[#22242C] text-[#FBE285]">Banco BAI</span>
                <span className="bg-[#131418] px-2 py-1 rounded border border-[#22242C] text-[#FBE285]">Banco BFA</span>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-[#22242C] flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] text-slate-500">
            <p>© {new Date().getFullYear()} CAPI STORE Angola. Edição Luxo & Tecnologia.</p>
            <p className="font-mono text-slate-600">Comércio digital de alta fidelidade e segurança.</p>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Live Button */}
      <a
        href={buildGeneralHelpWhatsAppUrl(
          storeSettings?.primaryWhatsapp || '+244972973849',
          primaryAttendant?.name
        )}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 p-3.5 bg-emerald-500 hover:bg-emerald-400 text-white rounded-full shadow-2xl shadow-emerald-500/40 flex items-center justify-center transition-all hover:scale-105 group cursor-pointer"
        title="Falar agora com um consultor comercial no WhatsApp"
      >
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
        </span>
        <MessageCircle className="w-6 h-6" />
      </a>

      {/* Global Modals */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenProduct={(p) => setSelectedProduct(p)}
      />

      <CartDrawer />
      <CheckoutModal />
      <AttendantsModal />
      <FavoritesDrawer />

      {/* Admin Panel Fullscreen Modal */}
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <StoreFront />
    </StoreProvider>
  );
}



