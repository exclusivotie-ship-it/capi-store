import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Attendant, StoreSettings, Coupon } from '../types/index.js';
import storeData from '../../public/store-data.json';

const staticStore = storeData as {
  products: Product[];
  attendants: Attendant[];
  storeSettings: StoreSettings;
};

interface StoreContextType {
  cart: CartItem[];
  favorites: Product[];
  storeSettings: StoreSettings | null;
  attendants: Attendant[];
  appliedCoupon: { code: string; discountAmount: number } | null;
  selectedProvince: string;
  isCartOpen: boolean;
  isCheckoutOpen: boolean;
  isFavoritesOpen: boolean;
  isAttendantsOpen: boolean;
  selectedProduct: Product | null;
  activeAttendantForCategory: (catId?: string) => Attendant | undefined;
  addToCart: (product: Product, quantity?: number, selectedColor?: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  toggleFavorite: (product: Product) => void;
  isFavorite: (productId: string) => boolean;
  applyCoupon: (code: string) => Promise<{ success: boolean; error?: string }>;
  removeCoupon: () => void;
  setSelectedProvince: (prov: string) => void;
  setIsCartOpen: (open: boolean) => void;
  setIsCheckoutOpen: (open: boolean) => void;
  setIsFavoritesOpen: (open: boolean) => void;
  setIsAttendantsOpen: (open: boolean) => void;
  setSelectedProduct: (p: Product | null) => void;
  cartSubtotal: number;
  deliveryFee: number;
  cartTotal: number;
  cartCount: number;
  refreshSettings: () => Promise<void>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const CART_STORAGE_KEY = 'electrostore_cart_v1';
const FAV_STORAGE_KEY = 'electrostore_favs_v1';

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [favorites, setFavorites] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(FAV_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [storeSettings, setStoreSettings] = useState<StoreSettings | null>(staticStore.storeSettings);
  const [attendants, setAttendants] = useState<Attendant[]>(staticStore.attendants);
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discountAmount: number } | null>(null);
  const [selectedProvince, setSelectedProvince] = useState<string>('Luanda');

  // Modals
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isAttendantsOpen, setIsAttendantsOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch (e) {
      console.warn('Failed to save cart to localStorage', e);
    }
  }, [cart]);

  // Sync favorites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(FAV_STORAGE_KEY, JSON.stringify(favorites));
    } catch (e) {
      console.warn('Failed to save favorites to localStorage', e);
    }
  }, [favorites]);

  const refreshSettings = async () => {
    setStoreSettings(staticStore.storeSettings);
    setAttendants(staticStore.attendants);
  };

  const addToCart = (product: Product, quantity = 1, selectedColor?: string) => {
    setCart((prev) => {
      const existingIdx = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedColor === selectedColor
      );
      if (existingIdx > -1) {
        const next = [...prev];
        next[existingIdx].quantity += quantity;
        return next;
      }
      return [
        ...prev,
        {
          product,
          quantity,
          selectedColor: selectedColor || (product.colors && product.colors[0]) || 'Padrão',
        },
      ];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity: Math.min(item.product.stock || 99, quantity) } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  const toggleFavorite = (product: Product) => {
    setFavorites((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      }
      return [...prev, product];
    });
  };

  const isFavorite = (productId: string) => {
    return favorites.some((p) => p.id === productId);
  };

  const applyCoupon = async (_code: string) => {
    return { success: false, error: 'Cupões precisam de validação num servidor e não estão disponíveis nesta versão estática.' };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const deliveryFee = React.useMemo(() => {
    if (!storeSettings) return 5000;
    const match = storeSettings.deliveryProvinces.find(
      (p) => p.name.toLowerCase() === selectedProvince.toLowerCase()
    );
    return match ? match.fee : 5000;
  }, [storeSettings, selectedProvince]);

  const discountAmount = appliedCoupon ? appliedCoupon.discountAmount : 0;
  const cartTotal = Math.max(0, cartSubtotal + deliveryFee - discountAmount);
  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);

  const activeAttendantForCategory = (catId?: string): Attendant | undefined => {
    if (!attendants.length) return undefined;
    if (catId) {
      const match = attendants.find(
        (a) => a.isActive && a.assignedCategories.some((c) => c.toLowerCase() === catId.toLowerCase())
      );
      if (match) return match;
    }
    // Fallback to primary or first active
    return attendants.find((a) => a.isActive && a.isPrimary) || attendants.find((a) => a.isActive);
  };

  return (
    <StoreContext.Provider
      value={{
        cart,
        favorites,
        storeSettings,
        attendants,
        appliedCoupon,
        selectedProvince,
        isCartOpen,
        isCheckoutOpen,
        isFavoritesOpen,
        isAttendantsOpen,
        selectedProduct,
        activeAttendantForCategory,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        toggleFavorite,
        isFavorite,
        applyCoupon,
        removeCoupon,
        setSelectedProvince,
        setIsCartOpen,
        setIsCheckoutOpen,
        setIsFavoritesOpen,
        setIsAttendantsOpen,
        setSelectedProduct,
        cartSubtotal,
        deliveryFee,
        cartTotal,
        cartCount,
        refreshSettings,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore deve ser usado dentro de um StoreProvider');
  }
  return context;
}


