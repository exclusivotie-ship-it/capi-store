export type OrderStatus =
  | 'Novo pedido'
  | 'Aguardando contacto'
  | 'Aguardando confirmação'
  | 'Confirmado'
  | 'Em preparação'
  | 'Pronto para entrega'
  | 'Em transporte'
  | 'Entregue'
  | 'Cancelado';

export interface Product {
  id: string;
  name: string;
  slug: string;
  brand: string;
  model: string;
  sku: string;
  categoryId: string;
  subcategoryId: string;
  descriptionShort: string;
  descriptionFull: string;
  price: number; // in Kwanza (Kz)
  originalPrice?: number;
  discountPercent?: number;
  stock: number;
  minStockAlert: number;
  rating: number;
  reviewCount: number;
  isPublished: boolean;
  isFeatured: boolean;
  isDeal: boolean;
  isNew: boolean;
  warranty: string;
  colors: string[];
  specs: Record<string, string>;
  images: string[];
  videoUrl?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  description: string;
  image: string;
  subcategories: string[];
}

export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo: string;
  description: string;
  isFeatured: boolean;
}

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  badgeText: string;
  imageUrl: string;
  categorySlug: string;
  buttonText: string;
  buttonLink: string;
  order: number;
  active: boolean;
  durationSeconds: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productModel: string;
  sku: string;
  price: number;
  quantity: number;
  selectedColor?: string;
  image: string;
}

export interface OrderStatusHistoryItem {
  status: OrderStatus;
  timestamp: string;
  note?: string;
  updatedBy?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerWhatsapp: string;
  customerEmail?: string;
  province: string;
  municipality: string;
  neighborhood: string;
  address: string;
  deliveryMethod: 'Levantamento em Loja' | 'Entrega ao Domicílio' | 'Entrega a Combinar';
  paymentMethod: 'Transferência Bancária' | 'Multicaixa Express' | 'Pagamento na Entrega';
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  couponCode?: string;
  status: OrderStatus;
  paymentStatus: 'Pendente' | 'Confirmado' | 'Recusado';
  internalNotes?: string;
  trackingCode: string;
  createdAt: string;
  statusHistory: OrderStatusHistoryItem[];
}

export interface Attendant {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  role: string;
  specialty: string;
  photo: string;
  isPrimary: boolean;
  isActive: boolean;
  workingHours: string;
  assignedCategories: string[]; // category IDs or slugs
}

export interface Coupon {
  id: string;
  code: string;
  discountPercent?: number;
  discountFixed?: number;
  minOrderAmount: number;
  expiresAt: string;
  isActive: boolean;
  usageCount: number;
}

export interface DeliveryProvince {
  name: string;
  fee: number;
  estimatedDays: string;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  phone: string;
  primaryWhatsapp: string;
  email: string;
  address: string;
  city: string;
  country: string;
  currency: string;
  ibanBai: string;
  ibanBfa: string;
  multicaixaNumber: string;
  deliveryProvinces: DeliveryProvince[];
}

export interface InventoryMovement {
  id: string;
  productId: string;
  productName: string;
  type: 'ENTRADA' | 'SAIDA' | 'AJUSTE' | 'RESERVA_PEDIDO';
  quantity: number;
  previousStock: number;
  newStock: number;
  reason: string;
  orderNumber?: string;
  date: string;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'superadmin' | 'manager' | 'operator';
  passwordHash: string;
  salt: string;
  lastLogin?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
}
