export function formatKz(amount: number): string {
  if (isNaN(amount)) return '0 Kz';
  return new Intl.NumberFormat('pt-AO', {
    style: 'decimal',
    maximumFractionDigits: 0,
  }).format(amount) + ' Kz';
}

export function formatDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    return new Intl.DateTimeFormat('pt-AO', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function buildProductWhatsAppUrl(
  phone: string,
  productName: string,
  model: string,
  price: number
): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const message = `Olá! Tenho interesse no produto ${productName}, modelo ${model || 'Original'}, anunciado por ${formatKz(price)}. Gostaria de saber mais informações e condições de compra.`;
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

export function buildCartWhatsAppUrl(
  phone: string,
  items: { productName: string; quantity: number; price: number }[],
  total: number
): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const itemsText = items.map((i) => `• ${i.quantity}x ${i.productName} (${formatKz(i.price * i.quantity)})`).join('\n');
  const message = `Olá! Gostaria de comprar os seguintes produtos:\n\n${itemsText}\n\nTotal estimado: ${formatKz(total)}\n\nPodem ajudar-me a finalizar o pedido?`;
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

export function buildOrderWhatsAppUrl(
  phone: string,
  orderNumber: string
): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const message = `Olá! Gostaria de obter informações sobre o meu pedido ${orderNumber}.`;
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

export function buildGeneralHelpWhatsAppUrl(
  phone: string,
  attendantName?: string
): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const greeting = attendantName ? `Olá ${attendantName}!` : 'Olá!';
  const message = `${greeting} Gostaria de atendimento personalizado para escolher produtos na CAPI STORE.`;
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}
