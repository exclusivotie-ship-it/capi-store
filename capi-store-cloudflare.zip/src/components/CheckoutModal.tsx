import React, { useState } from 'react';
import {
  X,
  CheckCircle,
  Truck,
  CreditCard,
  Building2,
  Copy,
  Check,
  MessageCircle,
  ShieldCheck,
  AlertCircle,
  ArrowRight,
} from 'lucide-react';
import { useStore } from '../context/StoreContext.js';
import { formatKz, buildCartWhatsAppUrl } from '../utils/format.js';

export const CheckoutModal: React.FC = () => {
  const {
    cart,
    cartSubtotal,
    deliveryFee,
    cartTotal,
    isCheckoutOpen,
    setIsCheckoutOpen,
    clearCart,
    storeSettings,
    selectedProvince,
    setSelectedProvince,
  } = useStore();

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+244 ');
  const [whatsapp, setWhatsapp] = useState('+244 ');
  const [email, setEmail] = useState('');
  const [municipality, setMunicipality] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState<'Levantamento em Loja' | 'Entrega ao Domicílio' | 'Entrega a Combinar'>('Entrega ao Domicílio');
  const [paymentMethod, setPaymentMethod] = useState<'Multicaixa Express' | 'Transferência Bancária' | 'Pagamento na Entrega'>('Multicaixa Express');

  // Submit states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [createdOrder, setCreatedOrder] = useState<{ orderNumber: string; customerName: string; customerPhone: string; province: string; municipality: string; address: string; paymentMethod: string; total: number } | null>(null);
  const [copiedIban, setCopiedIban] = useState<string | null>(null);

  if (!isCheckoutOpen) return null;

  const currentDeliveryFee = deliveryMethod === 'Levantamento em Loja' ? 0 : deliveryFee;
  const finalTotal = cartSubtotal + currentDeliveryFee;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIban(label);
    setTimeout(() => setCopiedIban(null), 2500);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !address.trim()) {
      setErrorMessage('Por favor, preencha o seu nome, contacto telefónico e endereço de entrega.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');

    try {
      const orderNumber = `ES-${Date.now().toString(36).toUpperCase()}`;
      const message = [`Olá! Quero confirmar esta encomenda (${orderNumber}):`, ...cart.map((item) => `• ${item.quantity}x ${item.product.name} — ${formatKz(item.product.price * item.quantity)}`), ``, `Subtotal: ${formatKz(cartSubtotal)}`, `Entrega: ${formatKz(currentDeliveryFee)}`, `Total estimado: ${formatKz(finalTotal)}`, ``, `Cliente: ${name}`, `Telefone: ${phone}`, `Província: ${selectedProvince}`, `Município: ${municipality}`, `Endereço: ${address}`, `Entrega: ${deliveryMethod}`, `Pagamento: ${paymentMethod}`, notes ? `Observações: ${notes}` : ''].filter(Boolean).join('\n');
      const whatsappUrl = `https://wa.me/${(storeSettings?.primaryWhatsapp || '+244972973849').replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
      setCreatedOrder({ orderNumber, customerName: name, customerPhone: phone, province: selectedProvince, municipality, address, paymentMethod, total: finalTotal });
      clearCart();
    } catch {
      setErrorMessage('Não foi possível abrir o WhatsApp. Copie os artigos e contacte a loja diretamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 lg:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#131418] border border-[#E5C158]/30 rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-[#22242C] flex items-center justify-between bg-[#0B0C0E]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#E5C158]/15 border border-[#E5C158]/30 flex items-center justify-center text-[#FBE285]">
              <Truck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {createdOrder ? 'Pedido Confirmado com Sucesso!' : 'Finalização do Pedido'}
              </h2>
              <p className="text-xs text-slate-400">
                {createdOrder
                  ? 'Acompanhe o estado da sua encomenda'
                  : 'Preencha os seus dados para envio e factura'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setIsCheckoutOpen(false);
              setCreatedOrder(null);
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-[#FBE285] hover:bg-[#252832] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="overflow-y-auto p-6 sm:p-8">
          {createdOrder ? (
            /* Order Success View */
            <div className="text-center py-6 space-y-6 max-w-xl mx-auto">
              <div className="w-20 h-20 rounded-full bg-emerald-500/10 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/20 animate-in zoom-in-75">
                <CheckCircle className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <span className="text-xs font-mono font-bold text-[#E5C158] uppercase tracking-wider">
                  CAPI STORE Angola · Encomenda Registada
                </span>
                <h3 className="text-2xl font-extrabold text-white">Muito obrigado pelo seu pedido!</h3>
                <p className="text-sm text-slate-300">
                  Referência para identificar a mensagem do seu pedido:
                </p>
                <div className="inline-block p-3 px-6 bg-[#0B0C0E] border-2 border-[#E5C158] rounded-2xl text-xl font-mono font-black text-[#FBE285] shadow-lg shadow-[#E5C158]/20">
                  {createdOrder.orderNumber}
                </div>
              </div>

              {/* Order Details Summary Card */}
              <div className="bg-[#0B0C0E] rounded-2xl p-5 border border-[#22242C] text-left text-xs space-y-3">
                <div className="flex justify-between border-b border-[#22242C] pb-2">
                  <span className="text-slate-400">Cliente:</span>
                  <span className="font-semibold text-white">{createdOrder.customerName}</span>
                </div>
                <div className="flex justify-between border-b border-[#22242C] pb-2">
                  <span className="text-slate-400">Telefone / WhatsApp:</span>
                  <span className="font-mono text-white">{createdOrder.customerPhone}</span>
                </div>
                <div className="flex justify-between border-b border-[#22242C] pb-2">
                  <span className="text-slate-400">Local de Entrega:</span>
                  <span className="font-medium text-white text-right">
                    {createdOrder.province}, {createdOrder.municipality} - {createdOrder.address}
                  </span>
                </div>
                <div className="flex justify-between border-b border-[#22242C] pb-2">
                  <span className="text-slate-400">Método de Pagamento:</span>
                  <span className="font-semibold text-emerald-400">{createdOrder.paymentMethod}</span>
                </div>
                <div className="flex justify-between text-sm font-bold pt-1">
                  <span className="text-white">Valor Total a Pagar:</span>
                  <span className="text-[#FBE285] font-mono text-base">{formatKz(createdOrder.total)}</span>
                </div>
              </div>

              {/* Bank Details / Multicaixa instructions if selected */}

              {/* Direct Next Steps CTAs */}
              <div className="space-y-3 pt-2">
                <a
                  href={buildOrderWhatsAppUrl(
                    storeSettings?.primaryWhatsapp || '+244972973849',
                    createdOrder.orderNumber
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-xl shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Enviar Confirmação / Comprovativo por WhatsApp</span>
                </a>

              </div>
            </div>
          ) : (
            /* Checkout Input Form */
            <form onSubmit={handleSubmitOrder} className="space-y-8">
              {errorMessage && (
                <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Left Form: Client Data (7 cols) */}
                <div className="lg:col-span-7 space-y-6">
                  {/* Step 1: Client Data */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#22242C] pb-2">
                      <span className="w-5 h-5 rounded-full gold-btn-gradient text-[#0B0C0E] text-[11px] flex items-center justify-center font-black">
                        1
                      </span>
                      Dados Pessoais do Cliente
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="sm:col-span-2">
                        <label className="block text-slate-300 font-semibold mb-1">
                          Nome Completo *
                        </label>
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Ex: Manuel Sebastião Van-Dúnem"
                          className="w-full bg-[#0B0C0E] text-white placeholder-slate-500 px-3.5 py-2.5 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">
                          Telefone Principal (Angola) *
                        </label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+244 9XX XXX XXX"
                          className="w-full bg-[#0B0C0E] text-white placeholder-slate-500 px-3.5 py-2.5 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">
                          WhatsApp para Notificações *
                        </label>
                        <input
                          type="tel"
                          value={whatsapp}
                          onChange={(e) => setWhatsapp(e.target.value)}
                          placeholder="+244 9XX XXX XXX"
                          className="w-full bg-[#0B0C0E] text-white placeholder-slate-500 px-3.5 py-2.5 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none font-mono"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-300 font-semibold mb-1">
                          E-mail (Opcional para recibo)
                        </label>
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="exemplo@gmail.com"
                          className="w-full bg-[#0B0C0E] text-white placeholder-slate-500 px-3.5 py-2.5 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Step 2: Delivery Location */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#22242C] pb-2">
                      <span className="w-5 h-5 rounded-full gold-btn-gradient text-[#0B0C0E] text-[11px] flex items-center justify-center font-black">
                        2
                      </span>
                      Localização e Método de Entrega em Angola
                    </h3>

                    {/* Delivery Method Choice */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                      {[
                        { id: 'Entrega ao Domicílio', title: 'Ao Domicílio', desc: 'Estafeta entrega no seu endereço' },
                        { id: 'Levantamento em Loja', title: 'Levantar na Loja', desc: 'Levantar na loja (localização a confirmar)' },
                        { id: 'Entrega a Combinar', title: 'A Combinar', desc: 'Ponto de encontro ou agência' },
                      ].map((opt) => (
                        <button
                          type="button"
                          key={opt.id}
                          onClick={() => setDeliveryMethod(opt.id as any)}
                          className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                            deliveryMethod === opt.id
                              ? 'bg-[#E5C158]/10 border-[#E5C158] text-white shadow-md shadow-[#E5C158]/10'
                              : 'bg-[#0B0C0E] border-[#22242C] text-slate-400 hover:border-slate-600'
                          }`}
                        >
                          <p className={`font-bold ${deliveryMethod === opt.id ? 'text-[#FBE285]' : 'text-white'}`}>{opt.title}</p>
                          <p className="text-[11px] text-slate-400 mt-0.5">{opt.desc}</p>
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">
                          Província de Destino *
                        </label>
                        <select
                          value={selectedProvince}
                          onChange={(e) => setSelectedProvince(e.target.value)}
                          className="w-full bg-[#0B0C0E] text-white px-3.5 py-2.5 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none"
                        >
                          {(storeSettings?.deliveryProvinces || []).map((prov) => (
                            <option key={prov.name} value={prov.name}>
                              {prov.name} ({formatKz(prov.fee)} - {prov.estimatedDays})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">
                          Município *
                        </label>
                        <input
                          type="text"
                          required
                          value={municipality}
                          onChange={(e) => setMunicipality(e.target.value)}
                          placeholder="Ex: Talatona, Belas, Maianga..."
                          className="w-full bg-[#0B0C0E] text-white placeholder-slate-500 px-3.5 py-2.5 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-300 font-semibold mb-1">
                          Bairro e Ponto de Referência
                        </label>
                        <input
                          type="text"
                          value={neighborhood}
                          onChange={(e) => setNeighborhood(e.target.value)}
                          placeholder="Ex: Alvalade / Próximo ao Supermercado Kero"
                          className="w-full bg-[#0B0C0E] text-white placeholder-slate-500 px-3.5 py-2.5 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-300 font-semibold mb-1">
                          Endereço Completo ou Rua *
                        </label>
                        <textarea
                          rows={2}
                          required
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          placeholder="Rua, número do edifício, andar ou instruções para o estafeta..."
                          className="w-full bg-[#0B0C0E] text-white placeholder-slate-500 px-3.5 py-2 rounded-xl border border-[#22242C] focus:border-[#E5C158] focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Step 3: Payment Method */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#22242C] pb-2">
                      <span className="w-5 h-5 rounded-full gold-btn-gradient text-[#0B0C0E] text-[11px] flex items-center justify-center font-black">
                        3
                      </span>
                      Método de Pagamento em Angola
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      {[
                        {
                          id: 'Multicaixa Express',
                          title: 'Multicaixa Express',
                          desc: 'Referência via telemóvel',
                          badge: 'Mais Rápido',
                        },
                        {
                          id: 'Transferência Bancária',
                          title: 'Transferência IBAN',
                          desc: 'Contas BAI ou BFA',
                          badge: 'Comprovativo',
                        },
                        {
                          id: 'Pagamento na Entrega',
                          title: 'Na Entrega',
                          desc: 'TPA ou numerário',
                          badge: 'Presencial',
                        },
                      ].map((pm) => (
                        <button
                          type="button"
                          key={pm.id}
                          onClick={() => setPaymentMethod(pm.id as any)}
                          className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative ${
                            paymentMethod === pm.id
                              ? 'bg-[#E5C158]/10 border-[#E5C158] text-white shadow-md shadow-[#E5C158]/10'
                              : 'bg-[#0B0C0E] border-[#22242C] text-slate-400 hover:border-slate-600'
                          }`}
                        >
                          <span className={`absolute top-2 right-2 text-[9px] px-1.5 py-0.5 rounded font-bold ${paymentMethod === pm.id ? 'bg-[#E5C158] text-[#0B0C0E]' : 'bg-white/10 text-slate-300'}`}>
                            {pm.badge}
                          </span>
                          <p className={`font-bold ${paymentMethod === pm.id ? 'text-[#FBE285]' : 'text-white'}`}>{pm.title}</p>
                          <p className="text-[11px] text-slate-400 mt-1">{pm.desc}</p>
                        </button>
                      ))}
                    </div>

                    {/* Payment Instruction Box */}
                    {paymentMethod === 'Multicaixa Express' && (
                      <div className="p-4 bg-[#0B0C0E] rounded-2xl border border-[#22242C] text-xs space-y-2">
                        <p className="text-slate-300">
                          Contacto CAPI STORE para confirmar o pagamento:{' '}
                          <span className="font-mono text-[#FBE285] font-black text-sm">
                            {storeSettings?.multicaixaNumber || '972973849'}
                          </span>
                        </p>
                        <p className="text-[11px] text-slate-400">
                          Após finalizar o pedido, o pagamento fica em estado &quot;Aguardando confirmação&quot;
                          até validação pelo operador comercial.
                        </p>
                      </div>
                    )}

                    {paymentMethod === 'Transferência Bancária' && (
                      <div className="p-4 bg-[#0B0C0E] rounded-2xl border border-[#22242C] text-xs space-y-2">
                        <p className="text-slate-300">
                          Contacte a loja pelo WhatsApp para combinar o
                          pagamento e comprovativo.
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Form: Order Summary (5 cols) */}
                <div className="lg:col-span-5 space-y-6">
                  <div className="p-5 bg-[#0B0C0E] rounded-2xl border border-[#22242C] space-y-4">
                    <h4 className="text-xs font-bold text-[#E5C158] uppercase tracking-wider">
                      Resumo da Encomenda ({cart.length} itens)
                    </h4>

                    {/* Items Mini List */}
                    <div className="space-y-3 max-h-52 overflow-y-auto pr-1">
                      {cart.map((item) => (
                        <div
                          key={`${item.product.id}-${item.selectedColor}`}
                          className="flex items-center gap-3 text-xs"
                        >
                          <img
                            src={item.product.images[0]}
                            alt=""
                            className="w-10 h-10 object-cover rounded-lg bg-black/40 border border-[#22242C] flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-white truncate">{item.product.name}</p>
                            <p className="text-[11px] text-slate-400">
                              Qtd: {item.quantity} · {formatKz(item.product.price)}
                            </p>
                          </div>
                          <span className="font-mono text-white font-bold">
                            {formatKz(item.product.price * item.quantity)}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Financial Calculations */}
                    <div className="pt-3 border-t border-[#22242C] space-y-2 text-xs">
                      <div className="flex justify-between text-slate-400">
                        <span>Subtotal</span>
                        <span className="font-mono text-white">{formatKz(cartSubtotal)}</span>
                      </div>


                      <div className="flex justify-between text-slate-400">
                        <span>Taxa de Envio ({selectedProvince})</span>
                        <span className="font-mono text-white">
                          {deliveryMethod === 'Levantamento em Loja' ? 'Grátis' : formatKz(currentDeliveryFee)}
                        </span>
                      </div>

                      <div className="flex justify-between text-sm font-extrabold text-white pt-2 border-t border-[#22242C]">
                        <span>Total a Pagar</span>
                        <span className="font-mono text-xl text-[#FBE285]">
                          {formatKz(finalTotal)}
                        </span>
                      </div>
                    </div>

                    {/* Submit Order Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 px-4 rounded-xl gold-btn-gradient text-[#0B0C0E] font-black text-sm transition-all shadow-xl shadow-[#E5C158]/30 hover:brightness-105 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>A registar pedido na base de dados...</span>
                      ) : (
                        <>
                          <span>Confirmar Pedido ({formatKz(finalTotal)})</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>

                    <div className="pt-2 text-[10px] text-slate-400 text-center space-y-1">
                      <p className="flex items-center justify-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-[#E5C158]" />
                        Não é necessário criar conta para encomendar.
                      </p>
                      <p>O comprovativo e código de rastreio serão emitidos de imediato.</p>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};



