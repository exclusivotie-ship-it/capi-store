import React from 'react';
import { ShoppingCart, Heart, MessageCircle, Star, Eye, ShieldCheck } from 'lucide-react';
import { Product } from '../types/index.js';
import { formatKz, buildProductWhatsAppUrl } from '../utils/format.js';
import { useStore } from '../context/StoreContext.js';

interface ProductCardProps {
  product: Product;
  onOpenDetail?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onOpenDetail }) => {
  const { addToCart, toggleFavorite, isFavorite, storeSettings, activeAttendantForCategory } = useStore();
  const favorite = isFavorite(product.id);

  const attendant = activeAttendantForCategory(product.categoryId);
  const whatsappNumber = attendant?.whatsapp || storeSettings?.primaryWhatsapp || '+244972973849';
  const whatsappUrl = buildProductWhatsAppUrl(
    whatsappNumber,
    product.name,
    product.model || product.sku,
    product.price
  );

  const isLowStock = product.stock > 0 && product.stock <= product.minStockAlert;
  const isOutOfStock = product.stock <= 0;

  return (
    <div className="group relative bg-[#131418] rounded-2xl border border-[#22242C] hover:border-[#E5C158]/50 transition-all duration-300 flex flex-col overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-[#E5C158]/10">
      {/* Top Media Container */}
      <div className="relative w-full pt-[85%] bg-[#0B0C0E] overflow-hidden">
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=900&auto=format&fit=crop'}
          alt={product.name}
          loading="lazy"
          className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
        />

        {/* Badges Overlay */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.discountPercent && product.discountPercent > 0 ? (
            <span className="bg-rose-600 text-white text-[11px] font-extrabold px-2 py-0.5 rounded-md shadow-md">
              -{product.discountPercent}%
            </span>
          ) : null}
          {product.isNew && (
            <span className="gold-btn-gradient text-[#0B0C0E] text-[11px] font-black px-2 py-0.5 rounded-md shadow-md tracking-wider">
              NOVO
            </span>
          )}
          {product.isFeatured && !product.isNew && (
            <span className="bg-[#E5C158] text-[#0B0C0E] text-[11px] font-black px-2 py-0.5 rounded-md shadow-md tracking-wider">
              DESTAQUE
            </span>
          )}
        </div>

        {/* Favorite Heart Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(product);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all z-10 cursor-pointer ${
            favorite
              ? 'bg-[#E5C158] text-[#0B0C0E] shadow-lg shadow-[#E5C158]/30'
              : 'bg-[#0B0C0E]/70 text-slate-300 hover:text-[#FBE285] hover:bg-[#0B0C0E]'
          }`}
          title={favorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
        >
          <Heart className={`w-4 h-4 ${favorite ? 'fill-current' : ''}`} />
        </button>

        {/* Quick View Button on Hover */}
        <button
          onClick={() => onOpenDetail && onOpenDetail(product)}
          className="absolute inset-x-4 bottom-3 py-2 bg-[#0B0C0E]/90 hover:bg-[#E5C158] hover:text-[#0B0C0E] text-white text-xs font-bold rounded-xl backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center gap-1.5 shadow-xl cursor-pointer"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Ver Especificações</span>
        </button>
      </div>

      {/* Content Area */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Brand & Stock Status */}
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-bold text-[#E5C158] tracking-wider uppercase">{product.brand}</span>
            {isOutOfStock ? (
              <span className="text-rose-400 font-medium">Esgotado</span>
            ) : isLowStock ? (
              <span className="text-amber-400 font-medium">Últimas {product.stock} un.</span>
            ) : (
              <span className="text-emerald-400 font-medium">Em Stock</span>
            )}
          </div>

          {/* Title */}
          <h3
            onClick={() => onOpenDetail && onOpenDetail(product)}
            className="font-semibold text-white text-sm line-clamp-2 hover:text-[#FBE285] transition-colors cursor-pointer"
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Model / SKU */}
          <p className="text-[11px] font-mono text-slate-500 truncate mt-0.5">
            {product.model || product.sku}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-2">
            <div className="flex text-[#FBE285]">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.floor(product.rating || 5) ? 'fill-current' : 'opacity-25'
                  }`}
                />
              ))}
            </div>
            <span className="text-[11px] text-slate-400 font-medium">
              {product.rating?.toFixed(1) || '5.0'} ({product.reviewCount || 12})
            </span>
          </div>
        </div>

        {/* Pricing & Actions */}
        <div className="pt-2 border-t border-[#22242C]">
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-lg sm:text-xl font-black text-white tracking-tight">
              {formatKz(product.price)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-xs text-slate-500 line-through">
                {formatKz(product.originalPrice)}
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            {/* Add to Cart */}
            <button
              onClick={() => addToCart(product, 1)}
              disabled={isOutOfStock}
              className={`w-full py-2.5 px-2 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                isOutOfStock
                  ? 'bg-[#22242C] text-slate-500 cursor-not-allowed'
                  : 'gold-btn-gradient text-[#0B0C0E] shadow-md shadow-[#E5C158]/20 hover:brightness-105 active:scale-95'
              }`}
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>{isOutOfStock ? 'Esgotado' : 'Carrinho'}</span>
            </button>

            {/* Direct WhatsApp Purchase with Personalized Encoded Message */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-bold text-xs transition-all flex items-center justify-center gap-1 text-center cursor-pointer hover:shadow-[0_0_12px_rgba(16,185,129,0.2)]"
              title="Comprar directamente por WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5 flex-shrink-0" />
              <span className="truncate">WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
