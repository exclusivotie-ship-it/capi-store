import React from 'react';
import { X, Heart, ShoppingCart, Trash2, ArrowRight } from 'lucide-react';
import { useStore } from '../context/StoreContext.js';
import { formatKz } from '../utils/format.js';

export const FavoritesDrawer: React.FC = () => {
  const {
    favorites,
    isFavoritesOpen,
    setIsFavoritesOpen,
    toggleFavorite,
    addToCart,
    setSelectedProduct,
  } = useStore();

  if (!isFavoritesOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#131418] border-l border-[#22242C] h-full flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-5 border-b border-[#22242C] flex items-center justify-between bg-[#0B0C0E]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#E5C158]/15 border border-[#E5C158]/30 flex items-center justify-center text-[#FBE285]">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Os Seus Favoritos</h2>
              <p className="text-xs text-slate-400">{favorites.length} produto(s) guardado(s)</p>
            </div>
          </div>

          <button
            onClick={() => setIsFavoritesOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-[#FBE285] hover:bg-[#252832] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {favorites.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#22242C]/60 flex items-center justify-center text-slate-500">
                <Heart className="w-8 h-8 opacity-40 text-[#E5C158]" />
              </div>
              <div>
                <p className="text-base font-semibold text-white">Nenhum favorito guardado</p>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">
                  Clique no ícone de coração nos produtos para guardar os seus equipamentos preferidos e comparar preços.
                </p>
              </div>
            </div>
          ) : (
            favorites.map((product) => (
              <div
                key={product.id}
                className="p-3 bg-[#0B0C0E] rounded-2xl border border-[#22242C] flex gap-3 relative group"
              >
                <img
                  src={product.images[0]}
                  alt={product.name}
                  onClick={() => {
                    setSelectedProduct(product);
                    setIsFavoritesOpen(false);
                  }}
                  className="w-16 h-16 object-cover rounded-xl bg-black/40 border border-[#22242C] flex-shrink-0 cursor-pointer"
                />

                <div className="flex-1 min-w-0 pr-6">
                  <p className="text-[10px] text-[#E5C158] font-bold uppercase">{product.brand}</p>
                  <p
                    onClick={() => {
                      setSelectedProduct(product);
                      setIsFavoritesOpen(false);
                    }}
                    className="text-xs font-semibold text-white truncate cursor-pointer hover:text-[#FBE285]"
                  >
                    {product.name}
                  </p>
                  <p className="text-xs font-mono font-bold text-white mt-1">
                    {formatKz(product.price)}
                  </p>

                  <div className="pt-2 flex items-center gap-2">
                    <button
                      onClick={() => addToCart(product, 1)}
                      className="px-3.5 py-1.5 gold-btn-gradient text-[#0B0C0E] text-[11px] font-black rounded-lg transition-colors flex items-center gap-1 cursor-pointer shadow-md shadow-[#E5C158]/20"
                    >
                      <ShoppingCart className="w-3 h-3" />
                      <span>Comprar</span>
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => toggleFavorite(product)}
                  className="absolute top-3 right-3 text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                  title="Remover dos favoritos"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
