import React, { useState } from 'react';
import {
  X,
  ShoppingCart,
  Heart,
  MessageCircle,
  ShieldCheck,
  Truck,
  RotateCcw,
  Star,
  Check,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { Product } from '../types/index.js';
import { formatKz, buildProductWhatsAppUrl } from '../utils/format.js';
import { useStore } from '../context/StoreContext.js';
import storeData from '../../public/store-data.json';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onOpenProduct: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onOpenProduct,
}) => {
  const {
    addToCart,
    toggleFavorite,
    isFavorite,
    storeSettings,
    activeAttendantForCategory,
    setIsCheckoutOpen,
  } = useStore();

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'specs' | 'desc'>('specs');
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);

  // Load related products
  React.useEffect(() => {
    if (!product) return;
    setSelectedImageIndex(0);
    setSelectedColor(product.colors && product.colors[0] ? product.colors[0] : 'Padrão');
    setQuantity(1);

    const data = storeData as { products: Product[] };
    setRelatedProducts(data.products.filter((p) => p.isPublished && p.categoryId === product.categoryId && p.id !== product.id).slice(0, 3));
  }, [product]);

  if (!product) return null;

  const favorite = isFavorite(product.id);
  const attendant = activeAttendantForCategory(product.categoryId);
  const whatsappNumber = attendant?.whatsapp || storeSettings?.primaryWhatsapp || '+244972973849';
  const whatsappUrl = buildProductWhatsAppUrl(
    whatsappNumber,
    product.name,
    product.model || product.sku,
    product.price
  );

  const isOutOfStock = product.stock <= 0;

  const handleBuyNow = () => {
    addToCart(product, quantity, selectedColor);
    onClose();
    setIsCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 lg:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-[#121318] border border-[#E5C158]/25 rounded-3xl shadow-2xl shadow-black overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-[#22242C] flex items-center justify-between bg-[#0B0C0E]">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-bold text-[#E5C158]">{product.brand}</span>
            <span>/</span>
            <span className="font-mono text-slate-300">{product.model || product.sku}</span>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-[#181A20] text-slate-400 hover:text-[#FBE285] hover:bg-[#252832] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Gallery Column (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="relative w-full pt-[90%] bg-[#0B0C0E] rounded-2xl overflow-hidden border border-[#22242C]">
                <img
                  src={product.images[selectedImageIndex] || product.images[0]}
                  alt={product.name}
                  className="absolute inset-0 w-full h-full object-cover object-center"
                />

                {product.discountPercent ? (
                  <span className="absolute top-3 left-3 bg-rose-600 text-white text-xs font-black px-2.5 py-1 rounded-lg">
                    -{product.discountPercent}% DESCONTO
                  </span>
                ) : null}
              </div>

              {/* Thumbnails */}
              {product.images.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImageIndex(idx)}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-all cursor-pointer ${
                        selectedImageIndex === idx
                          ? 'border-[#E5C158] ring-2 ring-[#E5C158]/30'
                          : 'border-[#22242C] opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Trust Badges */}
              <div className="p-4 bg-[#0B0C0E] rounded-xl border border-[#22242C] space-y-2.5 text-xs text-slate-300">
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-[#E5C158] flex-shrink-0" />
                  <span>{product.warranty || 'Garantia de 12 a 24 Meses Oficial'}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Truck className="w-4 h-4 text-[#E5C158] flex-shrink-0" />
                  <span>Envio rápido para Luanda e todas as províncias</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <RotateCcw className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Suporte técnico e verificação no acto de entrega</span>
                </div>
              </div>
            </div>

            {/* Product Info Column (7 cols) */}
            <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                {/* Brand & Availability */}
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-md bg-[#E5C158]/10 text-[#FBE285] border border-[#E5C158]/30 text-xs font-bold tracking-wider uppercase">
                    {product.brand}
                  </span>

                  {isOutOfStock ? (
                    <span className="text-xs font-bold text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-md">
                      Esgotado de momento
                    </span>
                  ) : (
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-md flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                      Em Stock ({product.stock} disponíveis)
                    </span>
                  )}
                </div>

                {/* Title */}
                <h1 className="text-xl sm:text-2xl font-bold text-white leading-tight">
                  {product.name}
                </h1>

                {/* Rating */}
                <div className="flex items-center gap-2">
                  <div className="flex text-[#FBE285]">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(product.rating || 5) ? 'fill-current' : 'opacity-25'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-slate-400">
                    {product.rating?.toFixed(1) || '5.0'} de 5 estrelas ({product.reviewCount || 15} avaliações)
                  </span>
                </div>

                {/* Pricing Box */}
                <div className="p-4 bg-[#0B0C0E] rounded-2xl border border-[#22242C] flex items-baseline justify-between">
                  <div>
                    <p className="text-xs text-[#E5C158] font-bold mb-1 tracking-wider uppercase">Preço Oficial CAPI STORE</p>
                    <div className="flex items-baseline gap-3">
                      <span className="text-2xl sm:text-3xl font-black text-white font-mono">
                        {formatKz(product.price)}
                      </span>
                      {product.originalPrice && product.originalPrice > product.price && (
                        <span className="text-sm text-slate-500 line-through">
                          {formatKz(product.originalPrice)}
                        </span>
                      )}
                    </div>
                  </div>

                  {product.discountPercent ? (
                    <div className="text-right">
                      <span className="text-xs text-[#FBE285] font-bold">
                        Poupe {formatKz(product.originalPrice! - product.price)}
                      </span>
                    </div>
                  ) : null}
                </div>

                {/* Colors Variant Picker */}
                {product.colors && product.colors.length > 0 && (
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-300">
                      Cor / Variante Seleccionada:{' '}
                      <span className="text-[#FBE285] font-bold">{selectedColor}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {product.colors.map((color) => (
                        <button
                          key={color}
                          onClick={() => setSelectedColor(color)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                            selectedColor === color
                              ? 'gold-btn-gradient text-[#0B0C0E] border-[#E5C158] shadow-md shadow-[#E5C158]/20'
                              : 'bg-[#0B0C0E] border-[#22242C] text-slate-300 hover:border-[#E5C158]/50'
                          }`}
                        >
                          {color}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity Selector */}
                <div className="flex items-center gap-4 pt-2">
                  <span className="text-xs font-semibold text-slate-300">Quantidade:</span>
                  <div className="flex items-center border border-[#22242C] bg-[#0B0C0E] rounded-xl overflow-hidden">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      disabled={quantity <= 1 || isOutOfStock}
                      className="px-3 py-1.5 text-slate-400 hover:text-white hover:bg-[#252832] transition-colors disabled:opacity-30 cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-4 py-1.5 text-sm font-bold text-white font-mono">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                      disabled={quantity >= product.stock || isOutOfStock}
                      className="px-3 py-1.5 text-slate-400 hover:text-white hover:bg-[#252832] transition-colors disabled:opacity-30 cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2.5 pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      onClick={() => {
                        addToCart(product, quantity, selectedColor);
                      }}
                      disabled={isOutOfStock}
                      className="w-full py-3.5 px-4 rounded-xl gold-btn-gradient text-[#0B0C0E] font-black text-sm transition-all shadow-lg shadow-[#E5C158]/25 hover:brightness-105 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      <span>Adicionar ao Carrinho</span>
                    </button>

                    <button
                      onClick={handleBuyNow}
                      disabled={isOutOfStock}
                      className="w-full py-3.5 px-4 rounded-xl bg-[#181920] hover:bg-[#22242C] text-[#FBE285] border border-[#E5C158]/40 hover:border-[#E5C158] font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                    >
                      <Zap className="w-4 h-4 text-[#FBE285]" />
                      <span>Comprar Imediatamente</span>
                    </button>
                  </div>

                  {/* Direct WhatsApp Concierge CTA */}
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 px-4 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 text-center cursor-pointer hover:shadow-[0_0_15px_rgba(16,185,129,0.25)]"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Falar com Atendente Especialista via WhatsApp</span>
                  </a>

                  {/* Favorite Toggle */}
                  <div className="flex justify-center">
                    <button
                      onClick={() => toggleFavorite(product)}
                      className="text-xs text-slate-400 hover:text-[#FBE285] flex items-center gap-1.5 py-1 cursor-pointer transition-colors"
                    >
                      <Heart className={`w-3.5 h-3.5 ${favorite ? 'fill-[#E5C158] text-[#E5C158]' : ''}`} />
                      <span>{favorite ? 'Remover dos meus Favoritos' : 'Guardar nos meus Favoritos'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs: Specifications & Description */}
          <div className="pt-6 border-t border-[#22242C]">
            <div className="flex items-center gap-2 border-b border-[#22242C] pb-3 mb-4">
              <button
                onClick={() => setActiveTab('specs')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'specs'
                    ? 'gold-btn-gradient text-[#0B0C0E] shadow-md shadow-[#E5C158]/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Características & Especificações Técnicas
              </button>
              <button
                onClick={() => setActiveTab('desc')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'desc'
                    ? 'gold-btn-gradient text-[#0B0C0E] shadow-md shadow-[#E5C158]/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Descrição Comercial Completa
              </button>
            </div>

            {activeTab === 'specs' ? (
              <div className="bg-[#0B0C0E] rounded-2xl border border-[#22242C] overflow-hidden">
                <table className="w-full text-xs text-left">
                  <tbody>
                    {Object.entries(product.specs || {}).map(([key, value], idx) => (
                      <tr
                        key={key}
                        className={`border-b border-[#22242C] last:border-0 ${
                          idx % 2 === 0 ? 'bg-transparent' : 'bg-[#181A20]/40'
                        }`}
                      >
                        <td className="py-3 px-4 font-bold text-[#E5C158] w-1/3 sm:w-1/4">
                          {key}
                        </td>
                        <td className="py-3 px-4 text-white font-medium">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="bg-[#0B0C0E] p-6 rounded-2xl border border-[#22242C] text-sm text-slate-300 leading-relaxed space-y-4">
                <p>{product.descriptionFull || product.descriptionShort}</p>
                <p className="text-xs text-[#E5C158] pt-2 border-t border-[#22242C] font-mono">
                  Garantia: {product.warranty} | Código SKU: {product.sku}
                </p>
              </div>
            )}
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="pt-6 border-t border-[#22242C]">
              <h3 className="text-base font-bold text-white mb-4 flex items-center justify-between">
                <span>Produtos Relacionados</span>
                <span className="text-xs text-[#E5C158] font-bold">Mesma Categoria</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {relatedProducts.map((rel) => (
                  <button
                    key={rel.id}
                    onClick={() => onOpenProduct(rel)}
                    className="p-3 bg-[#0B0C0E] hover:bg-[#181920] border border-[#22242C] hover:border-[#E5C158]/40 rounded-xl flex items-center gap-3 text-left transition-colors cursor-pointer group"
                  >
                    <img
                      src={rel.images[0]}
                      alt={rel.name}
                      className="w-14 h-14 object-cover rounded-lg bg-black/40 flex-shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[10px] text-[#E5C158] uppercase font-bold">{rel.brand}</p>
                      <p className="text-xs font-semibold text-white truncate group-hover:text-[#FBE285] transition-colors">
                        {rel.name}
                      </p>
                      <p className="text-xs font-mono font-bold text-white mt-1">
                        {formatKz(rel.price)}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
