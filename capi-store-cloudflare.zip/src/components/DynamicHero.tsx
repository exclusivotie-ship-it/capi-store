import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  ArrowRight,
  Sparkles,
  MessageCircle,
  Shield,
  Zap,
} from 'lucide-react';
import { HeroSlide } from '../types/index.js';
import { useStore } from '../context/StoreContext.js';
import { buildGeneralHelpWhatsAppUrl } from '../utils/format.js';

interface DynamicHeroProps {
  slides: HeroSlide[];
  onExploreProducts: () => void;
  onViewDeals: () => void;
}

export const DynamicHero: React.FC<DynamicHeroProps> = ({
  slides,
  onExploreProducts,
  onViewDeals,
}) => {
  const { storeSettings, activeAttendantForCategory, setIsAttendantsOpen } = useStore();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const activeSlides = slides && slides.length > 0 ? slides.filter((s) => s.active) : [];
  const currentSlide = activeSlides[currentIndex] || activeSlides[0];

  const durationMs = (currentSlide?.durationSeconds || 6) * 1000;
  const primaryAttendant = activeAttendantForCategory();

  // Progress bar animation & automatic slide switch
  useEffect(() => {
    if (!isPlaying || activeSlides.length <= 1) return;

    const intervalStep = 50; // update progress every 50ms
    const stepIncrement = (intervalStep / durationMs) * 100;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setCurrentIndex((idx) => (idx + 1) % activeSlides.length);
          return 0;
        }
        return prev + stepIncrement;
      });
    }, intervalStep);

    return () => clearInterval(interval);
  }, [currentIndex, isPlaying, durationMs, activeSlides.length]);

  // Reset progress on manual change
  const handleSelectSlide = (idx: number) => {
    setCurrentIndex(idx);
    setProgress(0);
  };

  const handleNext = () => {
    setCurrentIndex((idx) => (idx + 1) % activeSlides.length);
    setProgress(0);
  };

  const handlePrev = () => {
    setCurrentIndex((idx) => (idx - 1 + activeSlides.length) % activeSlides.length);
    setProgress(0);
  };

  if (!currentSlide) return null;

  return (
    <section className="relative w-full h-[580px] sm:h-[640px] lg:h-[700px] overflow-hidden bg-[#0B0C0E]">
      {/* Ambient Golden Rim Light Glow */}
      <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-[#E5C158]/10 rounded-full blur-3xl pointer-events-none z-15" />
      <div className="absolute bottom-10 right-1/4 w-80 h-80 bg-[#C89B2B]/10 rounded-full blur-3xl pointer-events-none z-15" />

      {/* Dynamic Background Slides with Fade & Cinematic Scale Effect */}
      {activeSlides.map((slide, index) => {
        const isActive = index === currentIndex;
        return (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
            }`}
          >
            {/* Cinematic zoom container */}
            <div
              className={`w-full h-full transform transition-transform duration-[6500ms] ease-out ${
                isActive ? 'scale-105' : 'scale-100'
              }`}
            >
              <img
                src={slide.imageUrl}
                alt={slide.title}
                className="w-full h-full object-cover object-center"
              />
            </div>

            {/* Dark & Gold Cinematic Gradient Overlay for Maximum Readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#0B0C0E] via-[#0B0C0E]/90 to-transparent sm:w-4/5 lg:w-3/5 z-10" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E] via-transparent to-black/50 z-10" />
            <div className="absolute inset-0 bg-[#C89B2B]/10 mix-blend-color-dodge pointer-events-none z-10" />
          </div>
        );
      })}

      {/* Hero Foreground Content */}
      <div className="relative z-20 max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
        <div className="max-w-2xl space-y-6">
          {/* Luxury Gold Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E5C158]/10 border border-[#E5C158]/40 backdrop-blur-md shadow-[0_0_15px_rgba(229,193,88,0.15)]">
            <Sparkles className="w-4 h-4 text-[#FBE285]" />
            <span className="text-xs font-bold text-[#FBE285] tracking-widest uppercase">
              {currentSlide.badgeText || 'TECNOLOGIA DE PONTA · LUXURY EDITION'}
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1]">
            {currentSlide.title || 'TECNOLOGIA QUE TRANSFORMA O SEU DIA.'}
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl font-normal">
            {currentSlide.subtitle ||
              'Descubra equipamentos electrónicos premium que combinam inovação, desempenho superior e atendimento personalizado.'}
          </p>

          {/* Action Functional CTAs */}
          <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4">
            <button
              onClick={onExploreProducts}
              className="px-6 py-3.5 rounded-xl gold-btn-gradient text-[#0B0C0E] font-black text-sm tracking-wide transition-all shadow-xl shadow-[#E5C158]/20 hover:shadow-[0_0_25px_rgba(229,193,88,0.4)] hover:brightness-105 flex items-center gap-2 group cursor-pointer"
            >
              <span>EXPLORAR CATÁLOGO</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onViewDeals}
              className="px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm tracking-wide transition-all backdrop-blur-md border border-[#E5C158]/30 hover:border-[#E5C158] flex items-center gap-2 cursor-pointer"
            >
              <Zap className="w-4 h-4 text-[#FBE285]" />
              <span>OFERTAS ESPECIAIS</span>
            </button>

            <a
              href={buildGeneralHelpWhatsAppUrl(
                storeSettings?.primaryWhatsapp || '+244972973849',
                primaryAttendant?.name
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 font-bold text-sm tracking-wide transition-all flex items-center gap-2 backdrop-blur-md cursor-pointer hover:shadow-[0_0_15px_rgba(16,185,129,0.2)]"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>FALAR COM ATENDENTE</span>
            </a>
          </div>

          {/* Value Props Strip */}
          <div className="pt-4 flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-slate-300">
            <span className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-[#E5C158]" />
              Garantia Oficial 12 a 24 Meses
            </span>
            <span className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-[#E5C158]" />
              Entrega Rápida em Luanda e Províncias
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#E5C158] shadow-[0_0_8px_#E5C158]"></span>
              Multicaixa Express / BAI Direto
            </span>
          </div>
        </div>
      </div>

      {/* Slider Controls & Progress Indicator */}
      <div className="absolute bottom-6 left-0 right-0 z-30 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Navigation Dots and Slide Numbers */}
        <div className="flex items-center gap-2 bg-[#0B0C0E]/85 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-[#E5C158]/20">
          {activeSlides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => handleSelectSlide(idx)}
              className={`h-2 transition-all rounded-full cursor-pointer ${
                idx === currentIndex ? 'w-8 bg-[#E5C158] shadow-[0_0_8px_#E5C158]' : 'w-2 bg-white/20 hover:bg-white/50'
              }`}
              title={`Ir para imagem ${idx + 1}`}
            />
          ))}

          <span className="text-[11px] font-mono text-[#E5C158] font-bold ml-2">
            0{currentIndex + 1} / 0{activeSlides.length}
          </span>
        </div>

        {/* Play/Pause & Prev/Next Arrows */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2.5 rounded-full bg-[#0B0C0E]/85 hover:bg-[#181920] text-slate-300 hover:text-[#FBE285] border border-[#E5C158]/20 hover:border-[#E5C158]/50 backdrop-blur-md transition-all cursor-pointer"
            title={isPlaying ? 'Pausar troca automática de 6s' : 'Retomar troca automática'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={handlePrev}
            className="p-2.5 rounded-full bg-[#0B0C0E]/85 hover:bg-[#181920] text-slate-300 hover:text-[#FBE285] border border-[#E5C158]/20 hover:border-[#E5C158]/50 backdrop-blur-md transition-all cursor-pointer"
            title="Imagem Anterior"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={handleNext}
            className="p-2.5 rounded-full bg-[#0B0C0E]/85 hover:bg-[#181920] text-slate-300 hover:text-[#FBE285] border border-[#E5C158]/20 hover:border-[#E5C158]/50 backdrop-blur-md transition-all cursor-pointer"
            title="Próxima Imagem"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 6-Second Linear Countdown Progress Bar with Gold Glow at Bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10 z-30">
        <div
          className="h-full bg-gradient-to-r from-[#C89B2B] via-[#E5C158] to-[#FBE285] shadow-[0_0_10px_#E5C158] transition-all duration-75 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>
    </section>
  );
};
