import React from 'react';
import { X, MessageCircle, Clock, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useStore } from '../context/StoreContext.js';
import { buildGeneralHelpWhatsAppUrl } from '../utils/format.js';

export const AttendantsModal: React.FC = () => {
  const { attendants, isAttendantsOpen, setIsAttendantsOpen, storeSettings } = useStore();

  if (!isAttendantsOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 lg:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#131418] border border-[#E5C158]/30 rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#22242C] flex items-center justify-between bg-[#0B0C0E]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <MessageCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Equipa de Atendimento Especializado</h2>
              <p className="text-xs text-slate-400">Consultoria técnica directa via WhatsApp Oficial</p>
            </div>
          </div>

          <button
            onClick={() => setIsAttendantsOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-[#FBE285] hover:bg-[#252832] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Attendants List */}
        <div className="overflow-y-auto p-6 space-y-4">
          <p className="text-xs text-slate-300 leading-relaxed">
            Selecione um dos nossos consultores para esclarecer dúvidas sobre especificações, garantias ou para finalizar encomendas personalizadas:
          </p>

          <div className="space-y-3">
            {attendants
              .filter((a) => a.isActive)
              .map((att) => {
                const url = buildGeneralHelpWhatsAppUrl(att.whatsapp, att.name);
                return (
                  <div
                    key={att.id}
                    className="p-4 bg-[#0B0C0E] rounded-2xl border border-[#22242C] hover:border-[#E5C158]/40 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="relative">
                        <img
                          src={att.photo}
                          alt={att.name}
                          className="w-14 h-14 rounded-2xl object-cover border border-[#22242C]"
                        />
                        <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#0B0C0E] rounded-full"></span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">{att.name}</h4>
                          {att.isPrimary && (
                            <span className="text-[10px] bg-[#E5C158]/20 border border-[#E5C158]/30 text-[#FBE285] font-bold px-2 py-0.5 rounded-full">
                              Principal
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-emerald-400 font-medium">{att.role}</p>
                        <p className="text-[11px] text-slate-400">{att.specialty}</p>
                        <p className="text-[10px] text-slate-500 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-400" /> {att.workingHours}
                        </p>
                      </div>
                    </div>

                    <a
                      href={url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer flex-shrink-0"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Falar no WhatsApp</span>
                    </a>
                  </div>
                );
              })}
          </div>

          <div className="p-4 bg-[#181920] border border-[#E5C158]/20 rounded-2xl text-xs text-slate-300 space-y-1.5">
            <p className="font-bold text-[#FBE285] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#E5C158]" /> Atendimento Corporativo B2B
            </p>
            <p className="text-slate-400 text-[11px]">
              Para cotações em grande escala ou fornecimento institucional para empresas em Angola, contacte:{' '}
              <span className="text-white font-mono">{storeSettings?.email || 'alicamara9@gmail.com'}</span> ou através da nossa linha directa:{' '}
              <span className="text-[#FBE285] font-mono">{storeSettings?.phone || '+244 972 973 849 / +244 958 690 893'}</span>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
