import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  ShoppingCart,
  Heart,
  MessageCircle,
  Truck,
  ShieldCheck,
  Menu,
  X,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { useStore } from '../context/StoreContext.js';
import { formatKz, buildGeneralHelpWhatsAppUrl } from '../utils/format.js';
import { Product } from '../types/index.js';
import storeData from '../../public/store-data.json';

interface HeaderProps {
  onNavigateCategory: (categorySlug: string) => void;
  selectedCategorySlug: string;
}

export const Header: React.FC<HeaderProps> = ({
  onNavigateCategory,
  selectedCategorySlug,
}) => {
  const {
    cartCount,
    cartSubtotal,
    favorites,
    storeSettings,
    setIsCartOpen,
    setIsFavoritesOpen,
    setIsAttendantsOpen,
    setSelectedProduct,
    activeAttendantForCategory,
  } = useStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const primaryAttendant = activeAttendantForCategory();

  // Live search debouncing
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setShowSearchDropdown(false);
      return;
    }

    const timer = setTimeout(() => {
      setIsSearching(true);
      const data = storeData as { products: Product[] };
      const query = searchQuery.trim().toLowerCase();
      setSearchResults(data.products.filter((p) => p.isPublished && `${p.name} ${p.brand} ${p.model} ${p.sku}`.toLowerCase().includes(query)).slice(0, 6));
      setShowSearchDropdown(true);
      setIsSearching(false);
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Click outside to close search dropdown
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearchDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navCategories = [
    { label: 'Todos os Produtos', slug: 'todos' },
    { label: 'Smartphones', slug: 'cat-smartphones' },
    { label: 'Computadores', slug: 'cat-computadores' },
    { label: 'Televisores', slug: 'cat-televisores' },
    { label: 'Gaming', slug: 'cat-gaming' },
    { label: 'Áudio & Som', slug: 'cat-audio' },
    { label: 'Smartwatches', slug: 'cat-smartwatches' },
    { label: 'Fotografia', slug: 'cat-fotografia' },
    { label: 'Tablets', slug: 'cat-tablets' },
    { label: 'Acessórios', slug: 'cat-acessorios' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0C0E]/95 backdrop-blur-md border-b border-[#252833] transition-colors">
      {/* Top Luxury Announcement Bar with Golden Lighting Accent */}
      <div className="bg-gradient-to-r from-[#14120B] via-[#1E190D] to-[#14120B] text-xs text-amber-200/90 py-1.5 px-4 border-b border-[#E5C158]/20 relative overflow-hidden">
        {/* Subtle Ambient Gold Light Beam */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#E5C158]/10 to-transparent pointer-events-none" />

        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 relative z-10">
          <div className="flex items-center gap-4 text-[11px] sm:text-xs">
            <span className="flex items-center gap-1.5 text-[#FBE285] font-semibold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#E5C158] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#E5C158]"></span>
              </span>
              Atendimento VIP em Luanda
            </span>
            <span className="hidden md:inline text-amber-500/30">|</span>
            <span className="hidden md:flex items-center gap-1 text-slate-300">
              <Truck className="w-3.5 h-3.5 text-[#E5C158]" /> Entregas para todas as províncias de Angola
            </span>
            <span className="hidden lg:inline text-amber-500/30">|</span>
            <span className="hidden lg:flex items-center gap-1 text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-[#E5C158]" /> Garantia Oficial & Certificado de Autenticidade
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] sm:text-xs">
            <a
              href={buildGeneralHelpWhatsAppUrl(
                storeSettings?.primaryWhatsapp || '+244972973849',
                primaryAttendant?.name
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#FBE285] hover:text-white font-medium flex items-center gap-1 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5 text-[#E5C158]" />
              WhatsApp Oficial: {storeSettings?.phone || '+244 972 973 849 / +244 958 690 893'}
            </a>
          </div>
        </div>
      </div>

      {/* Main Luxury Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
        {/* Brand Logo with Glowing Golden Lighting */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateCategory('todos')}
            className="group text-left cursor-pointer flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FBE285] via-[#E5C158] to-[#997B28] p-0.5 shadow-lg shadow-[#E5C158]/25 flex items-center justify-center group-hover:shadow-[#E5C158]/40 transition-shadow">
              <div className="w-full h-full bg-[#0B0C0E] rounded-[10px] flex items-center justify-center group-hover:bg-[#121318] transition-colors">
                <span className="font-black text-xl tracking-tighter gold-text-gradient">ES</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-wider text-white">CAPI</span>
                <span className="font-black text-lg sm:text-xl tracking-wider gold-text-gradient">STORE</span>
              </div>
              <p className="text-[10px] text-amber-200/60 uppercase tracking-widest font-mono flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-[#E5C158]" /> Venda Telemóveis e Acessórios
              </p>
            </div>
          </button>
        </div>

        {/* Intelligent Live Search Bar with Golden Focus Glow */}
        <div ref={searchRef} className="hidden md:flex flex-1 max-w-xl relative">
          <div className="w-full relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => {
                if (searchResults.length > 0) setShowSearchDropdown(true);
              }}
              placeholder="Pesquisar iPhone, Samsung Galaxy, TV 4K, PS5, Auscultadores..."
              className="w-full bg-[#121318] text-sm text-white placeholder-slate-400 pl-10 pr-10 py-2.5 rounded-xl border border-[#252833] focus:border-[#E5C158] focus:outline-none focus:ring-2 focus:ring-[#E5C158]/25 transition-all shadow-inner"
            />
            <Search className="w-4 h-4 text-[#E5C158] absolute left-3.5 top-3" />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSearchResults([]);
                  setShowSearchDropdown(false);
                }}
                className="absolute right-3.5 top-3 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Search Dropdown */}
          {showSearchDropdown && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-[#121318] border border-[#E5C158]/30 rounded-2xl shadow-2xl shadow-[#E5C158]/10 overflow-hidden z-50 max-h-96 overflow-y-auto">
              {isSearching ? (
                <div className="p-4 text-center text-sm text-slate-400">A pesquisar catálogo exclusivo...</div>
              ) : searchResults.length > 0 ? (
                <div>
                  <div className="p-2.5 bg-[#0B0C0E] text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex justify-between items-center border-b border-[#252833]">
                    <span>Resultados Sugeridos ({searchResults.length})</span>
                    <span className="text-[#FBE285]">Preços em Kwanza (Kz)</span>
                  </div>
                  {searchResults.map((product) => (
                    <button
                      key={product.id}
                      onClick={() => {
                        setSelectedProduct(product);
                        setShowSearchDropdown(false);
                        setSearchQuery('');
                      }}
                      className="w-full flex items-center gap-3 p-3 hover:bg-[#1C1E26] transition-colors text-left border-b border-[#252833]/50 last:border-0 cursor-pointer"
                    >
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded-xl bg-black/40 border border-[#E5C158]/20 flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-[#E5C158] font-bold uppercase tracking-wider">{product.brand}</p>
                        <p className="text-sm font-semibold text-white truncate">{product.name}</p>
                        <p className="text-xs text-slate-400 font-mono">{product.model || product.sku}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-sm font-bold text-white font-mono">{formatKz(product.price)}</p>
                        {product.stock > 0 ? (
                          <span className="text-[10px] text-emerald-400 font-medium">Em Stock</span>
                        ) : (
                          <span className="text-[10px] text-rose-400 font-medium">Indisponível</span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center text-sm text-slate-400">
                  Nenhum produto encontrado para &quot;{searchQuery}&quot;. Tente pesquisar por marca ou categoria.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* WhatsApp Direct Concierge with Golden/Green Pulse */}
          <button
            onClick={() => setIsAttendantsOpen(true)}
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#1C1E26] border border-[#E5C158]/30 text-[#FBE285] hover:border-[#E5C158] hover:bg-[#252833] transition-all text-xs font-semibold cursor-pointer shadow-sm hover:shadow-[#E5C158]/15"
            title="Falar com Atendente Especialista"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#E5C158] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#E5C158]"></span>
            </span>
            <MessageCircle className="w-4 h-4 text-[#E5C158]" />
            <span className="hidden xl:inline">Atendimento VIP</span>
          </button>

          {/* Favorites */}
          <button
            onClick={() => setIsFavoritesOpen(true)}
            className="relative p-2.5 rounded-xl bg-[#121318] border border-[#252833] text-slate-300 hover:text-white hover:border-[#E5C158]/50 transition-colors cursor-pointer"
            title="Produtos Favoritos"
          >
            <Heart className="w-5 h-5" />
            {favorites.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#E5C158] text-black text-[11px] font-black rounded-full flex items-center justify-center shadow-md">
                {favorites.length}
              </span>
            )}
          </button>

          {/* Luxury Gold Cart Toggle Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl gold-btn-gradient text-black font-extrabold text-xs sm:text-sm transition-all shadow-lg shadow-[#E5C158]/25 cursor-pointer active:scale-95"
          >
            <div className="relative">
              <ShoppingCart className="w-4 h-4 text-black" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2.5 w-4 h-4 bg-black text-[#FBE285] text-[10px] font-black rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
            <span className="hidden sm:inline font-mono text-xs">{formatKz(cartSubtotal)}</span>
          </button>


          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2.5 rounded-xl bg-[#121318] border border-[#252833] text-slate-300 hover:text-white md:hidden cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Search Bar */}
      <div className="md:hidden px-4 pb-3">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Pesquisar smartphones, TVs, consolas..."
            className="w-full bg-[#121318] text-sm text-white placeholder-slate-400 pl-10 pr-4 py-2 rounded-xl border border-[#252833] focus:border-[#E5C158] focus:outline-none"
          />
          <Search className="w-4 h-4 text-[#E5C158] absolute left-3 top-2.5" />
        </div>
      </div>

      {/* Category Navigation Bar (Horizontal Scrollable with Gold Highlights) */}
      <nav className="border-t border-[#252833]/80 bg-[#0B0C0E]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-1.5 overflow-x-auto no-scrollbar py-2 text-xs">
          {navCategories.map((cat) => {
            const isActive = selectedCategorySlug === cat.slug;
            return (
              <button
                key={cat.slug}
                onClick={() => onNavigateCategory(cat.slug)}
                className={`whitespace-nowrap px-3.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'gold-btn-gradient text-black shadow-md shadow-[#E5C158]/30'
                    : 'text-slate-400 hover:text-white hover:bg-[#1C1E26] border border-transparent hover:border-[#E5C158]/20'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0B0C0E] border-t border-[#252833] p-4 space-y-4">
          <div className="space-y-1">
            <p className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider px-2">Categorias</p>
            {navCategories.map((cat) => (
              <button
                key={cat.slug}
                onClick={() => {
                  onNavigateCategory(cat.slug);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between p-2.5 rounded-lg text-sm transition-colors ${
                  selectedCategorySlug === cat.slug
                    ? 'gold-btn-gradient text-black font-bold'
                    : 'text-slate-300 hover:bg-[#1C1E26]'
                }`}
              >
                <span>{cat.label}</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-[#252833] space-y-2">
            <button
              onClick={() => {
                setIsAttendantsOpen(true);
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 p-2.5 rounded-lg text-sm text-[#FBE285] hover:bg-[#1C1E26]"
            >
              <MessageCircle className="w-4 h-4 text-[#E5C158]" /> Atendimento Especializado WhatsApp
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
