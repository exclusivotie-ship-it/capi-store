import React, { useState } from 'react';
import {
  X,
  ShoppingCart,
  Trash2,
  ArrowRight,
  MessageCircle,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { useStore } from '../context/StoreContext.js';
import { formatKz, buildCartWhatsAppUrl } from '../utils/format.js';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    setIsCheckoutOpen,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartSubtotal,
    storeSettings,
    activeAttendantForCategory,
  } = useStore();


  if (!isCartOpen) return null;

  const primaryAttendant = activeAttendantForCategory();
  const whatsappNumber = primaryAttendant?.whatsapp || storeSettings?.primaryWhatsapp || '+244972973849';

  const estimatedTotal = cartSubtotal;

  const cartWhatsAppUrl = buildCartWhatsAppUrl(
    whatsappNumber,
    cart.map((item) => ({
      productName: item.product.name,
      quantity: item.quantity,
      price: item.product.price,
    })),
    estimatedTotal
  );

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#131418] border-l border-[#22242C] h-full flex flex-col shadow-2xl">
        {/* Drawer Header */}
        <div className="p-5 border-b border-[#22242C] flex items-center justify-between bg-[#0B0C0E]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#E5C158]/15 border border-[#E5C158]/30 flex items-center justify-center text-[#FBE285]">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Carrinho de Compras</h2>
              <p className="text-xs text-slate-400">Sem necessidade de registo prévio</p>
            </div>
          </div>

          <button
            onClick={() => setIsCartOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-[#FBE285] hover:bg-[#252832] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#22242C]/60 flex items-center justify-center text-slate-500">
                <ShoppingCart className="w-8 h-8 opacity-40 text-[#E5C158]" />
              </div>
              <div>
                <p className="text-base font-semibold text-white">O seu carrinho está vazio</p>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">
                  Explore o nosso catálogo com smartphones, portáteis e equipamentos de tecnologia premium.
                </p>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="px-5 py-2.5 rounded-xl gold-btn-gradient text-[#0B0C0E] text-xs font-bold hover:brightness-105 transition-colors cursor-pointer shadow-lg shadow-[#E5C158]/20"
              >
                Começar a Comprar
              </button>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center text-xs text-slate-400 pb-1">
                <span>{cart.length} item(ns) adicionado(s)</span>
                <button
                  onClick={clearCart}
                  className="text-rose-400 hover:text-rose-300 font-medium cursor-pointer"
                >
                  Limpar tudo
                </button>
              </div>

              {cart.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedColor}`}
                  className="p-3 bg-[#0B0C0E] rounded-2xl border border-[#22242C] flex gap-3 relative group"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded-xl bg-black/40 border border-[#22242C] flex-shrink-0"
                  />

                  <div className="flex-1 min-w-0 pr-6">
                    <p className="text-[10px] text-[#E5C158] font-bold uppercase">{item.product.brand}</p>
                    <p className="text-xs font-semibold text-white truncate">{item.product.name}</p>
                    {item.selectedColor && (
                      <p className="text-[11px] text-slate-400">Variante: {item.selectedColor}</p>
                    )}
                    <p className="text-xs font-mono font-bold text-white mt-1">
                      {formatKz(item.product.price)}
                    </p>

                    {/* Quantity controls */}
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center border border-[#22242C] bg-[#181A20] rounded-lg">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          className="px-2 py-0.5 text-xs text-slate-400 hover:text-white"
                        >
                          -
                        </button>
                        <span className="px-2 py-0.5 text-xs font-bold font-mono text-white">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          className="px-2 py-0.5 text-xs text-slate-400 hover:text-white"
                        >
                          +
                        </button>
                      </div>

                      <span className="text-[11px] font-mono text-slate-400">
                        = {formatKz(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="absolute top-3 right-3 text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                    title="Remover item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}

            </>
          )}
        </div>

        {/* Drawer Footer with Calculations and Finalize Button */}
        {cart.length > 0 && (
          <div className="p-5 border-t border-[#22242C] bg-[#0B0C0E] space-y-4">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Subtotal dos Produtos</span>
                <span className="font-mono text-white">{formatKz(cartSubtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Entrega</span>
                <span className="text-slate-300">Calculada no checkout</span>
              </div>
              <div className="flex justify-between text-sm font-extrabold text-white pt-2 border-t border-[#22242C]">
                <span>Total Estimado</span>
                <span className="font-mono text-[#FBE285] text-base">{formatKz(estimatedTotal)}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              <button
                onClick={() => {
                  setIsCartOpen(false);
                  setIsCheckoutOpen(true);
                }}
                className="w-full py-3.5 px-4 rounded-xl gold-btn-gradient text-[#0B0C0E] font-black text-sm transition-all shadow-xl shadow-[#E5C158]/25 hover:brightness-105 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Finalizar Pedido Agora</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Direct WhatsApp Order CTA */}
              <a
                href={cartWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 font-bold text-xs transition-all flex items-center justify-center gap-2 text-center cursor-pointer hover:shadow-[0_0_12px_rgba(16,185,129,0.2)]"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Finalizar Carrinho pelo WhatsApp Oficial</span>
              </a>
            </div>

            <p className="text-[10px] text-center text-slate-400 flex items-center justify-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#E5C158]" />
              Ambiente 100% Seguro · Pagamento Multicaixa ou Transferência
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

